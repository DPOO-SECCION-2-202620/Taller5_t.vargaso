package uniandes.dpoo.hamburguesas.tests;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.io.File;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
public class PedidoTest {
    private Pedido pedido;
    @BeforeEach
    void setUp() {
        pedido = new Pedido("Tomas", "Calle 123");
    }

    @Test
    void testGetNombreCliente() {
        assertEquals("Tomas", pedido.getNombreCliente(),"nombr del cliente debe corresponder");
    }

    @Test
    void testAgregarProductoYPrecios() {
        ProductoMenu prod1 = new  ProductoMenu("corral", 14000);
        pedido.agregarProducto(prod1);
        int neto = pedido.getPrecioNetoPedido();
        assertEquals(14000, neto,    "el precio no es ");
        int iva = pedido.getPrecioIVAPedido();
        // 19% 
        assertEquals((int) (14000 * 0.19), iva,  "L'IVA n'o es");
        int total = pedido.getPrecioTotalPedido();
        assertEquals(neto + iva, total, "el precio total neto mas iva no es el total");
    }

    @Test
    void testGenerarYGuardarFactura() throws Exception{
        ProductoMenu prod1 = new ProductoMenu("corral",14000);
        pedido.agregarProducto(prod1);
        String factura = pedido.generarTextoFactura();
        assertTrue(factura.contains("Tomas"),"La factura debe incluir el nombre");
        assertTrue(factura.contains("14000"),"La facture deb e tener el prize.");
        File archivo = new File("factura_test.txt");
        pedido.guardarFactura(archivo);
        assertTrue(archivo.exists(),"toca crear el archivo antes.");

        if (archivo.exists()) {
            archivo.delete();
        }
    }
}