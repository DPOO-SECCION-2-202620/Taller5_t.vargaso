package uniandes.dpoo.hamburguesas.tests;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api. BeforeEach;
import org.junit.jupiter.api. Test;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
public class ProductoMenuTest  {
    private ProductoMenu productoMenu;
    @BeforeEach
    void setUp( ) {
        productoMenu =  new ProductoMenu("corral",14000);
     }
    @Test
    void testGetNombre() {
        assertEquals("corral", productoMenu.getNombre(),"El nombre no coincide.");
    }
    @Test
    void testGetPrecio(){
        assertEquals(14000,productoMenu.getPrecio(), "El precio  no coincide.");
     }
    @Test
    void testGenerarTextoFactura()  {
        String esperado = "corral\n            14000\n"; 
        assertEquals(esperado, productoMenu.generarTextoFactura(), "El texto de la factura no coincide.");
     }
}