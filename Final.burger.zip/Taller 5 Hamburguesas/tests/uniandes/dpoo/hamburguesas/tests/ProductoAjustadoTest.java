package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoAjustadoTest  {
 
    private ProductoAjustado productoAjustado;
    private ProductoMenu productoBase ;

    @BeforeEach
    void setUp( ) {
        productoBase = new ProductoMenu("corral", 14000);
        productoAjustado = new ProductoAjustado(productoBase);
      }

    @Test
    void testGetNombre() {
        assertEquals("corral", productoAjustado.getNombre(), "El nombre debe coincidir con el producto");
    }

    @Test
    void testGetPrecioSinAjustes( )  {
        assertEquals(14000, productoAjustado.getPrecio(), "El precio base deb mantenerse");
     }
}