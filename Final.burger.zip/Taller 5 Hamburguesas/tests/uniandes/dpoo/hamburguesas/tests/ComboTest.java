package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
public class ComboTest {
    private Combo  combo;
    private  ArrayList<ProductoMenu> items;
    @BeforeEach
    void setUp( )  {
        items = new ArrayList<>();
        items.add(new ProductoMenu("corral", 14000));
        items.add(new ProductoMenu("papas medianas", 5500));
        items.add(new ProductoMenu("gaseosa", 5000));
        combo = new Combo("combo corral", 0.10, items);
    }

    @Test
    void  testGetNombre() {
        assertEquals("combo corral",  combo.getNombre(), "nombre del combo no coincide");
    }

     @Test
    void testGetPrecio() {
        assertEquals(22050, combo.getPrecio(),"precio del combo con descuento no es correcto");
    }

    @Test
    void testGenerarTextoFactura()  {
        String factura = combo.generarTextoFactura();
        assertTrue(factura.contains("Combo combo corral"), "La factura debe incluir nombre del combo");
        assertTrue(factura.contains("22050"), "La factura debe incluir precio final calculado");
        assertTrue(factura.contains("0.1"), "La factura debe incluir porcentaje de  descuento");
     }
}