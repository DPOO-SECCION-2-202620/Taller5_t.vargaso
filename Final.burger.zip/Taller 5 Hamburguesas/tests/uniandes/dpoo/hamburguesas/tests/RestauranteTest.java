package uniandes.dpoo.hamburguesas.tests;
import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.excepciones.*;
public class RestauranteTest {
	private Restaurante restaurante;
	
	@BeforeEach
    void setUp() {
        restaurante  = new Restaurante();
    }

    @Test
    void testCargarInformacionRestaurante() {
        File ingredientes  = new File("data/ingredientes.txt");
        File menu =new File("data/menu.txt");
        File combos =new File("data/combos.txt");
        
        try {
            restaurante.cargarInformacionRestaurante(ingredientes, menu, combos);
            assertTrue(restaurante.getIngredientes().size() > 0, "Los ingredientes deben incluirse");
            assertTrue(restaurante.getMenuBase().size() > 0, "el menu debe estar incluido");
            assertTrue(restaurante.getMenuCombos().size() > 0, "Los combos deben cargarse.");
        } catch (Exception e) {
            fail("ficheros invalidos");
        }
    }

    @Test
    void testIniciarPedido() throws YaHayUnPedidoEnCursoException {
        restaurante.iniciarPedido("Tomas", "Calle 146");
        Pedido enCurso = restaurante.getPedidoEnCurso();
        assertNotNull(enCurso, "debe ejecutarse un comando ");
        assertEquals("Tomas", enCurso.getNombreCliente(), "wl nombr'e del cliente debe coincidr");
    }
    
    @Test
    void testIniciarPedidoConPedidoEnCurso() throws YaHayUnPedidoEnCursoException {
        restaurante.iniciarPedido("Tomas", "Calle 146");    
        assertThrows(YaHayUnPedidoEnCursoException.class, () -> {
            restaurante.iniciarPedido("otro Cliente", "Calle 456");
        }, "YaHayUnPedidoEnCursoException.");
    }

    @Test
    void testCerrarYGuardarPedido() throws YaHayUnPedidoEnCursoException, NoHayPedidoEnCursoException, IOException {
        restaurante.iniciarPedido("Tomas", "Calle 146");
        restaurante.cerrarYGuardarPedido();
             	 
        
        assertNull(restaurante.getPedidoEnCurso(),"el pedido en curso debe ser nulo antes de seguir");
        assertEquals(1, restaurante.getPedidos().size(), "see deberia guardar el comando");
    }
    @Test
    void testCerrarPedidoSinPedidoEnCurso() {
        assertThrows(NoHayPedidoEnCursoException.class, () -> {
            restaurante.cerrarYGuardarPedido();
        }, "NoHayPedidoEnCursoException.");
    }
}
